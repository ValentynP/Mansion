package SuperMonster;

import Game.*;

import javax.swing.*;

public class SuperMonster {
    public static ImageIcon monsterPicture;
    public String name;
    public int hp;
    public int damage;
    public String weapon;
}
