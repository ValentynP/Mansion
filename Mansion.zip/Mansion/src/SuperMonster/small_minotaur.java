package SuperMonster;

import javax.swing.*;

public class small_minotaur extends SuperMonster {
    public small_minotaur() {
        //monsterPicture = new ImageIcon( "Pictures/Smallmino.jpg");
        monsterPicture = new ImageIcon( getClass().getClassLoader().getResource("Smallmino.jpg"));

        name = "Small Minotaur";
        hp = 3000;
        damage = 10;
        weapon = "Morgenshtern";
    }

}
