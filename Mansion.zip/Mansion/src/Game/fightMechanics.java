package Game;

import game2.*;
import SuperMonster.*;
public class fightMechanics {
    Game game;
    Interfacce ui;
    Visibility vm;
    public fightMechanics(Game g, Interfacce u, Visibility v) {
        game = g;
        ui = u;
        vm = v;
    }

}
