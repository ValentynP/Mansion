package game2;

public class SuperWeapon {
    public String name;
    public int damage;
}
