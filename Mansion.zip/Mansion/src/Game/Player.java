package Game;

import game2.SuperWeapon;

public class Player {
    public int hp;
    public SuperWeapon currentWeapon;
    public int gold;
    public int healnum;

}
