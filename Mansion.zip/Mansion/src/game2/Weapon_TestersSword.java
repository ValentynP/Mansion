package game2;

public class Weapon_TestersSword extends SuperWeapon{
    public Weapon_TestersSword() {
        name = "Tester's Sword";
        damage = 5000;
    }
}
