package game2;

public class none extends SuperWeapon{
    public none(){
        name = "None";
        damage = 0;
    }
}
