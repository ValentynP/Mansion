package SuperMonster;

import javax.swing.*;

public class goblin_archer extends SuperMonster{
    public goblin_archer(){
        //monsterPicture = new ImageIcon( "Pictures/GoblinArcher.jpg");
        monsterPicture = new ImageIcon( getClass().getClassLoader().getResource("GoblinArcher.jpg"));

                name = "Goblin archer";
        hp = 60;
        damage = 15;
        weapon = "Bow";
    }
}
