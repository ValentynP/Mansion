package game2;

public class heal extends SuperWeapon{
    public heal(){
        name = "Healing Potion";
        damage = 50;
    }
}
