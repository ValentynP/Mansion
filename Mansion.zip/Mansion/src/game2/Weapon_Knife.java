package game2;

public class Weapon_Knife extends SuperWeapon{
    public Weapon_Knife(){
        name = "Knife";
        damage = 10;

    }
}
