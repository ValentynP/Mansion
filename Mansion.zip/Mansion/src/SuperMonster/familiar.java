package SuperMonster;

import javax.swing.*;

public class familiar extends SuperMonster {
    public familiar() {
        monsterPicture = new ImageIcon( getClass().getClassLoader().getResource("FamiliarFight_.jpg"));

        //monsterPicture = new ImageIcon( "Pictures/FamiliarFight_.jpg");
        name = "Familiar";
        hp = 25;
        damage = 15;
        weapon = "Claws";
    }

}
