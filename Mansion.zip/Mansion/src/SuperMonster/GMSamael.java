package SuperMonster;

public class GMSamael extends SuperMonster {
    public GMSamael() {
        name = "Game Master Samael";
        hp = 5000;
        damage = 20;
        weapon = "Fire element";
    }
}
